package com.hz.music

import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableHighestRefreshRate()
    }

    @Suppress("DEPRECATION")
    private fun enableHighestRefreshRate() {
        try {
            val attrs = window.attributes

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val displayRef = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    windowManager.defaultDisplay
                }

                val bestMode = displayRef?.supportedModes
                    ?.maxByOrNull { it.refreshRate }

                if (bestMode != null) {
                    attrs.preferredDisplayModeId = bestMode.modeId
                    attrs.preferredRefreshRate = bestMode.refreshRate
                } else {
                    attrs.preferredRefreshRate = 120f
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                attrs.preferredRefreshRate = 120f
            }

            window.attributes = attrs
        } catch (_: Exception) {
            // If the device blocks refresh-rate selection, Flutter still runs normally.
        }
    }
}
