import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:on_audio_query/on_audio_query.dart';

void main() {
  runApp(const HzMusicApp());
}

class HzMusicApp extends StatelessWidget {
  const HzMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFFFF8A00);
    return MaterialApp(
      title: 'Hz Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B0708),
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF1A1113),
        ),
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Roboto'),
      ),
      home: const MusicHomePage(),
    );
  }
}

class MusicHomePage extends StatefulWidget {
  const MusicHomePage({super.key});

  @override
  State<MusicHomePage> createState() => _MusicHomePageState();
}

class _MusicHomePageState extends State<MusicHomePage> {
  final AudioPlayer _player = AudioPlayer();
  final OnAudioQuery _audioQuery = OnAudioQuery();
  final TextEditingController _searchController = TextEditingController();

  List<SongModel> _songs = [];
  SongModel? _currentSong;
  String _query = '';
  bool _loading = false;
  bool _scanning = true;
  bool _permissionDenied = false;

  @override
  void initState() {
    super.initState();
    _scanLocalSongs();
  }

  @override
  void dispose() {
    _player.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _scanLocalSongs() async {
    setState(() {
      _scanning = true;
      _permissionDenied = false;
    });

    var hasPermission = await _audioQuery.permissionsStatus();
    if (!hasPermission) {
      hasPermission = await _audioQuery.permissionsRequest();
    }

    if (!hasPermission) {
      if (!mounted) return;
      setState(() {
        _permissionDenied = true;
        _scanning = false;
      });
      return;
    }

    final result = await _audioQuery.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );

    final playable = result.where((song) {
      final title = song.title.trim();
      final data = song.data.toLowerCase();
      final durationOk = (song.duration ?? 0) > 30000;
      final fileLooksAudio = data.endsWith('.mp3') ||
          data.endsWith('.m4a') ||
          data.endsWith('.aac') ||
          data.endsWith('.wav') ||
          data.endsWith('.flac') ||
          data.endsWith('.ogg');
      return title.isNotEmpty && durationOk && fileLooksAudio;
    }).toList();

    if (!mounted) return;
    setState(() {
      _songs = playable;
      _scanning = false;
    });
  }

  List<SongModel> get _filteredSongs {
    if (_query.trim().isEmpty) return _songs;
    final q = _query.toLowerCase();
    return _songs.where((song) {
      final text = '${song.title} ${song.artist ?? ''} ${song.album ?? ''}'.toLowerCase();
      return text.contains(q);
    }).toList();
  }

  Future<void> _playSong(SongModel song) async {
    try {
      setState(() {
        _loading = true;
        _currentSong = song;
      });

      final uri = song.uri;
      if (uri != null && uri.isNotEmpty) {
        await _player.setAudioSource(AudioSource.uri(Uri.parse(uri)));
      } else {
        await _player.setFilePath(song.data);
      }
      await _player.play();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not play ${song.title}. Try another local song.')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _togglePlay() async {
    if (_currentSong == null) {
      if (_filteredSongs.isNotEmpty) await _playSong(_filteredSongs.first);
      return;
    }
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> _skip(int direction) async {
    final list = _filteredSongs.isNotEmpty ? _filteredSongs : _songs;
    if (list.isEmpty) return;
    final current = _currentSong;
    final index = current == null ? -1 : list.indexWhere((song) => song.id == current.id);
    final nextIndex = index < 0 ? 0 : (index + direction) % list.length;
    final safeIndex = nextIndex < 0 ? list.length - 1 : nextIndex;
    await _playSong(list[safeIndex]);
  }

  @override
  Widget build(BuildContext context) {
    final visibleSongs = _filteredSongs;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 4),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset(
                      'assets/hz_logo.png',
                      width: 58,
                      height: 58,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hz Music',
                          style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Local downloaded songs',
                          style: TextStyle(color: Colors.white60),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Rescan songs',
                    onPressed: _scanning ? null : _scanLocalSongs,
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 46,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                scrollDirection: Axis.horizontal,
                children: const [
                  HzChip(label: 'Offline'),
                  HzChip(label: 'Downloads'),
                  HzChip(label: '16-bit ready'),
                  HzChip(label: 'FLAC/WAV'),
                  HzChip(label: 'Hz Surround soon'),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 10),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF3A1615), Color(0xFF14090B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: const Color(0x44FFB199)),
                  boxShadow: const [
                    BoxShadow(color: Color(0x66000000), blurRadius: 28, offset: Offset(0, 16)),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Your phone library', style: TextStyle(color: Color(0xFFFFC0CB))),
                          const SizedBox(height: 6),
                          Text(
                            _currentSong?.title ?? '${_songs.length} local songs found',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _currentSong?.artist ?? 'MP3 • M4A • WAV • FLAC • OGG',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                    StreamBuilder<bool>(
                      stream: _player.playingStream,
                      builder: (context, snapshot) {
                        final playing = snapshot.data ?? false;
                        return FilledButton.tonal(
                          onPressed: _loading || _songs.isEmpty ? null : _togglePlay,
                          child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: InputDecoration(
                  hintText: 'Search local songs...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _query = '');
                          },
                        ),
                  filled: true,
                  fillColor: const Color(0xFF1B1214),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _BodyState(
                scanning: _scanning,
                permissionDenied: _permissionDenied,
                visibleSongs: visibleSongs,
                currentSong: _currentSong,
                onSongTap: _playSong,
                onScan: _scanLocalSongs,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: MiniPlayer(
        player: _player,
        song: _currentSong,
        loading: _loading,
        onPlayPause: _togglePlay,
        onPrevious: () => _skip(-1),
        onNext: () => _skip(1),
      ),
    );
  }
}

class HzChip extends StatelessWidget {
  const HzChip({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: BoxDecoration(
        color: const Color(0xFF211719),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
    );
  }
}

class _BodyState extends StatelessWidget {
  const _BodyState({
    required this.scanning,
    required this.permissionDenied,
    required this.visibleSongs,
    required this.currentSong,
    required this.onSongTap,
    required this.onScan,
  });

  final bool scanning;
  final bool permissionDenied;
  final List<SongModel> visibleSongs;
  final SongModel? currentSong;
  final ValueChanged<SongModel> onSongTap;
  final VoidCallback onScan;

  @override
  Widget build(BuildContext context) {
    if (scanning) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Scanning downloaded songs...'),
          ],
        ),
      );
    }

    if (permissionDenied) {
      return EmptyState(
        icon: Icons.lock_rounded,
        title: 'Audio permission needed',
        message: 'Allow audio/music permission so Hz Music can scan songs saved on your phone.',
        buttonText: 'Allow permission',
        onPressed: onScan,
      );
    }

    if (visibleSongs.isEmpty) {
      return EmptyState(
        icon: Icons.library_music_rounded,
        title: 'No local songs found',
        message: 'Download MP3, M4A, WAV, FLAC or OGG songs into your phone Music/Downloads folder, then tap Rescan.',
        buttonText: 'Rescan songs',
        onPressed: onScan,
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 118),
      itemCount: visibleSongs.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (context, index) {
        final song = visibleSongs[index];
        final active = currentSong?.id == song.id;
        return Material(
          color: active ? const Color(0x22FFB199) : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
            leading: SongArtwork(song: song, size: 54),
            title: Text(
              song.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: active ? FontWeight.w900 : FontWeight.w700),
            ),
            subtitle: Text(
              song.artist == '<unknown>' || song.artist == null ? 'Unknown artist' : song.artist!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: Icon(active ? Icons.graphic_eq_rounded : Icons.play_arrow_rounded, size: 34),
            onTap: () => onSongTap(song),
          ),
        );
      },
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    required this.buttonText,
    required this.onPressed,
  });

  final IconData icon;
  final String title;
  final String message;
  final String buttonText;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 72, color: const Color(0xFFFFC0CB)),
            const SizedBox(height: 18),
            Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(message, style: const TextStyle(color: Colors.white60), textAlign: TextAlign.center),
            const SizedBox(height: 20),
            FilledButton.tonal(onPressed: onPressed, child: Text(buttonText)),
          ],
        ),
      ),
    );
  }
}

class SongArtwork extends StatelessWidget {
  const SongArtwork({super.key, required this.song, required this.size});

  final SongModel song;
  final double size;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.25),
      child: QueryArtworkWidget(
        id: song.id,
        type: ArtworkType.AUDIO,
        artworkFit: BoxFit.cover,
        nullArtworkWidget: Container(
          width: size,
          height: size,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFF8A00), Color(0xFF6D2838)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 30),
        ),
      ),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({
    super.key,
    required this.player,
    required this.song,
    required this.loading,
    required this.onPlayPause,
    required this.onPrevious,
    required this.onNext,
  });

  final AudioPlayer player;
  final SongModel? song;
  final bool loading;
  final VoidCallback onPlayPause;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    final activeSong = song;
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF120D0F).withOpacity(0.98),
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08))),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              PositionBar(player: player),
              Row(
                children: [
                  activeSong == null
                      ? Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xFF26181B),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: const Icon(Icons.music_note_rounded, size: 32),
                        )
                      : SongArtwork(song: activeSong, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          activeSong?.title ?? 'No song playing',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        Text(
                          activeSong == null
                              ? 'Tap a local song to play'
                              : (activeSong.artist == '<unknown>' || activeSong.artist == null ? 'Unknown artist' : activeSong.artist!),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, color: Colors.white60),
                        ),
                      ],
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.skip_previous_rounded), onPressed: onPrevious),
                  StreamBuilder<bool>(
                    stream: player.playingStream,
                    builder: (context, snapshot) {
                      final playing = snapshot.data ?? false;
                      if (loading) {
                        return const SizedBox(
                          width: 48,
                          height: 48,
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        );
                      }
                      return IconButton(
                        icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, size: 42),
                        onPressed: onPlayPause,
                      );
                    },
                  ),
                  IconButton(icon: const Icon(Icons.skip_next_rounded), onPressed: onNext),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PositionBar extends StatelessWidget {
  const PositionBar({super.key, required this.player});

  final AudioPlayer player;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: player.positionStream,
      builder: (context, positionSnapshot) {
        return StreamBuilder<Duration?>(
          stream: player.durationStream,
          builder: (context, durationSnapshot) {
            final position = positionSnapshot.data ?? Duration.zero;
            final duration = durationSnapshot.data ?? Duration.zero;
            final max = math.max(duration.inMilliseconds.toDouble(), 1);
            final value = math.min(position.inMilliseconds.toDouble(), max);
            return SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 2,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
              ),
              child: Slider(
                value: value,
                max: max,
                onChanged: duration == Duration.zero
                    ? null
                    : (newValue) {
                        player.seek(Duration(milliseconds: newValue.round()));
                      },
              ),
            );
          },
        );
      },
    );
  }
}
