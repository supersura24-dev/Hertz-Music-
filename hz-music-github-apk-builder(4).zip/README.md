# Hz Music v2 Local Player

Flutter music player prototype for local downloaded songs.

## What this version includes
- Official Hz Music logo and Android launcher icon
- Dark premium Hz Music interface
- Local downloaded-song scan and playback
- MP3, M4A, AAC, WAV, FLAC, and OGG file filtering
- Search local songs
- Mini player controls
- Android high-refresh-rate request for smoother UI on supported 90Hz/120Hz displays

## Notes
The app requests the highest available Android display refresh mode when it opens. Actual 120Hz depends on the phone display, battery saver, system refresh-rate settings, and device/OEM limits.

## Build APK
Upload this ZIP as `hz-music-github-apk-builder.zip` in the repository root and run the existing GitHub Actions workflow.
